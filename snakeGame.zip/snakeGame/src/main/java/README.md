### The Snake

A simple snake game in java .
Using Threads and Java Swing to display the game.
The code is well commented, if you have any questions or want to continue this project feel free to do so 👌

### How it looks:
![alt tag](http://i62.tinypic.com/behbw3.png)

### How to run the project:

#### Requirements:
* Java runtime installed

#### How to play the game:

* Just download the SnakeGame.jar file
* Run it 
* Start playing with the arrows keys. 
* If you lose, just close it and re-open it (I will add a restart button possibly)
